/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import sw.ConversionSW;
import view.LogIn;
import view.Registro;
import view.Transaccion;

/**
 *
 * @author Bryan
 */
public class ControllerUsuario {

    LogIn vLongIn;
    ConversionSW cliente;

    public ControllerUsuario(LogIn vLongIn, ConversionSW cliente) {
        this.vLongIn = vLongIn;
        this.cliente = cliente;
        vLongIn.setLocationRelativeTo(null);
        vLongIn.setVisible(true);
        vLongIn.setTitle("Iniciar Sesion");
    }

    public void inicialControl() {
        vLongIn.getBtnRegistrar().addActionListener(l -> registro());
        vLongIn.getBtnIngresar().addActionListener(l -> LogIn());

    }

    public void registro() {
        Registro registro = new Registro();
        ControllerRegistro controllerRegistro = new ControllerRegistro(registro, cliente);
        controllerRegistro.inicialControl();
    }

    public void transaccion(String user, String pass) {
        Transaccion transaccion = new Transaccion();
        ControllerTransaccion controllerTransaccion = new ControllerTransaccion(transaccion, cliente, user, pass);
        controllerTransaccion.inicialControl();

    }

    public void LogIn() {
//        System.out.println(cliente);
        String user = vLongIn.getTxtUser().getText(),
                password = vLongIn.getTxtPassword().getText();
        String ms = cliente.logIn(user, password);

        if (ms.equalsIgnoreCase("OK")) {
            transaccion(user, password);
            limpiar();
        } else {
            vLongIn.getTxtAlerta().setText(ms);
        }

    }

    public void limpiar() {
        vLongIn.getTxtAlerta().setText("");
        vLongIn.getTxtPassword().setText("");
        vLongIn.getTxtUser().setText("");

    }
}
