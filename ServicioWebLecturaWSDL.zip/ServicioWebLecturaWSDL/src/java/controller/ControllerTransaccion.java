/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import sw.ConversionSW;
import view.Transaccion;

/**
 *
 * @author Bryan
 */
public class ControllerTransaccion {

    Transaccion vTransaccion;
    ConversionSW cliente;
    String user, pass;

    int id;
    double saldo;

    public ControllerTransaccion(Transaccion vTransaccion, ConversionSW cliente, String user, String pass) {
        this.vTransaccion = vTransaccion;
        this.cliente = cliente;
        this.user = user;
        this.pass = pass;
        vTransaccion.setLocationRelativeTo(null);
        vTransaccion.setVisible(true);
        vTransaccion.setTitle("Transacciones");
        id = cliente.obtenerDatos(user, pass).getId();
        saldo = cliente.obtenerDatos(user, pass).getSaldo();
        cargarDatos();
    }

    public void inicialControl() {
        vTransaccion.getTxtValor().addKeyListener(restringirDouble);
        vTransaccion.getBtnAceptar().addActionListener(l -> transaccion());

    }

    public void transaccion() {
        String tipo = "",
                valor = vTransaccion.getTxtValor().getText(),
                saldo = vTransaccion.getTxtSaldo().getText();
        if (vTransaccion.getRbtnRetiro().isSelected()) {
            tipo = vTransaccion.getRbtnRetiro().getText();
        }
        if (vTransaccion.getRbtnDeposito().isSelected()) {
            tipo = vTransaccion.getRbtnDeposito().getText();
        }
        int idUser = id;

        String mensaje = cliente.transaccion(tipo, valor, idUser, saldo);

        vTransaccion.getTxtAlerta().setText(mensaje);
        if (mensaje.equalsIgnoreCase("Transaccion exitosa")) {
            vTransaccion.getTxtSaldo().setText(String.valueOf(cliente.obtenerDatos(user, pass).getSaldo()));
            JOptionPane.showMessageDialog(vTransaccion, mensaje);
            limpiar();
        }
    }

    public void cargarDatos() {
        vTransaccion.getTxtUser().setText(user);
        vTransaccion.getTxtSaldo().setText(String.valueOf(saldo));
    }

    public void limpiar() {
        vTransaccion.getTxtValor().setText("");
        vTransaccion.getBtgTipo().clearSelection();

    }
    //RESTRICCIONES
    KeyListener restringirDouble = new KeyListener() {
        @Override
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
            if (!Character.isDigit(c) && c != '.' && c != '-' && c != ',') {
                e.consume();  // ignora el carácter
            }
        }

        @Override
        public void keyPressed(KeyEvent e) {
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    };

}
