/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import sw.ConversionSW;
import view.Registro;

/**
 *
 * @author Bryan
 */
public class ControllerRegistro {

    Registro vregistro;
    ConversionSW cliente;

    public ControllerRegistro(Registro vregistro, ConversionSW cliente) {
        this.vregistro = vregistro;
        this.cliente = cliente;
        vregistro.setLocationRelativeTo(null);
        vregistro.setVisible(true);
        vregistro.setTitle("Registro");
    }

    public void inicialControl() {
        vregistro.getBtnRegistrar().addActionListener(l -> registrar());
        vregistro.getTxtSaldo().addKeyListener(restringirDouble);
    }

    public void registrar() {
//        System.out.println(cliente);
        String user = "",
                password = "",
                password2 = "",
                saldo = "";

        user = vregistro.getTxtUser().getText();
        password = vregistro.getTxtPassword().getText();
        password2 = vregistro.getTxtPassword2().getText();
        saldo = vregistro.getTxtSaldo().getText();

        String mensaje = cliente.registro(user, password, password2, saldo);

        vregistro.getTxtAlerta().setText(mensaje);
        if (mensaje.equalsIgnoreCase("Registro exitoso")) {
            JOptionPane.showMessageDialog(vregistro, mensaje);
            limpiar();
        }

    }

    public void limpiar() {
        vregistro.getTxtAlerta().setText("");
        vregistro.getTxtPassword().setText("");
        vregistro.getTxtPassword2().setText("");
        vregistro.getTxtUser().setText("");
        vregistro.getTxtSaldo().setText("");

    }
    //RESTRICCIONES
    KeyListener restringirDouble = new KeyListener() {
        @Override
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
            if (!Character.isDigit(c) && c != '.' && c != '-' && c != ',') {
                e.consume();  // ignora el carácter
            }
        }

        @Override
        public void keyPressed(KeyEvent e) {
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    };

}
